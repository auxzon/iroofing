import 'package:get/get.dart';

class EnterOTPController extends GetxController
{}