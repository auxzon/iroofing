import 'package:flutter/material.dart';
import 'package:iroofing/common/Color/Colordata.dart';

class CommonTextField extends StatelessWidget {
  final TextEditingController? controller;
  final String? hintText;
  final String? labelText;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final bool isPassword;
  final TextInputType keyboardType;
  final TextCapitalization textCapitalization;
  final TextInputAction? textInputAction;
  final Function(String)? onChanged;
  final Function(String)? onSubmitted;
  final String? Function(String?)? validator;
  final FocusNode? focusNode;
  final int? maxLength;
  final int? maxLines;
  final VoidCallback? onTap;
  final double? border;
  final double? enableborder;
  final double? focusborder;
  final double? errorborder;
  final double? errorfocusborder;
  final double? contentpadding;
  final bool readOnly;
  final TextStyle? hintstyle;

  const CommonTextField({
    Key? key,
    this.controller,
    this.hintText,
    this.labelText,
    this.prefixIcon,
    this.suffixIcon,
    this.isPassword = false,
    this.keyboardType = TextInputType.text,
    this.textCapitalization = TextCapitalization.none,
    this.textInputAction,
    this.onChanged,
    this.onSubmitted,
    this.validator,
    this.focusNode,
    this.maxLength,
    this.maxLines = 1,
    this.readOnly = false,
    this.onTap,
    this.border,
    this.focusborder,
    this.enableborder,
    this.errorborder,
    this.errorfocusborder,
    this.contentpadding,
    this.hintstyle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      textCapitalization: textCapitalization,
      textInputAction: textInputAction,
      obscureText: isPassword,
      maxLength: maxLength,
      maxLines: maxLines,
      readOnly: readOnly,
      focusNode: focusNode,
      onChanged: onChanged,
      onSubmitted: onSubmitted,
      onTap: onTap,
      decoration: InputDecoration(
        hintStyle: hintstyle,
        contentPadding: EdgeInsets.all(contentpadding??0),
        hintText: hintText,
        labelText: labelText,
        prefixIcon: prefixIcon ?? null,
        suffixIcon: suffixIcon ?? null,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(border??15),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(enableborder??15),
          borderSide:  BorderSide(color: ColorData.textfieldunfocuscolor),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(focusborder??15),
          borderSide:  BorderSide(color: ColorData.textfieldfocuscolor),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(errorborder??15),
          borderSide: BorderSide(color:ColorData.textfieldfocuscolor),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(errorfocusborder??15),
          borderSide: const BorderSide(color: Colors.redAccent),
        ),
        counterText: '',
      ),
    );
  }
}
