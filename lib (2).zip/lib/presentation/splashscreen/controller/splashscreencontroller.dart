import 'package:get/get.dart';
import 'package:iroofing/presentation/login/ui/loginpage.dart';

class SplashscreenController extends GetxController{
  switchfromsplahscreen()async{
    Future.delayed(Duration(seconds: 2),() {
      Get.off(()=>Loginpage());
    },);
  }
  @override
  void onInit() {
    switchfromsplahscreen();
    // TODO: implement onInit
    super.onInit();
  }
}