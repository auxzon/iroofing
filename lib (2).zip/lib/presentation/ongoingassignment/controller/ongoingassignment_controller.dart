import 'package:get/get.dart';

class OngoingScrrenController extends GetxController
{}