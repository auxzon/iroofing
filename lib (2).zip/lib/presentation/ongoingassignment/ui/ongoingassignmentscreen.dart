import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iroofing/common/Color/Colordata.dart';
import 'package:iroofing/common/elevted_button/ElevatedButton.dart';
import 'package:iroofing/common/text/textdata.dart';
import 'package:iroofing/presentation/ongoingassignment/controller/ongoingassignment_controller.dart';

import '../../../common/common_textfield/common_textfield.dart';
import '../../../main.dart';

class Ongoingassignmentscreen extends StatelessWidget {
  const Ongoingassignmentscreen({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(OngoingScrrenController());
    return Container(
      color: ColorData.bgcolor,
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 20),
      child: Column(
        children: [
          Row(
            children: [
              TextThemedel(
                text: "Ongoing  Assignment",
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: ColorData.maincolor,
              ),
              SizedBox(
                width: MyApp.width * .04,
              ),
              Expanded(
                child: SizedBox(
                    height: MyApp.height * .04,
                    child: CommonTextField(
                      border: 10,
                      focusborder: 10,
                      enableborder: 10,
                      maxLines: 1,
                      maxLength: 20,
                      prefixIcon: Icon(
                        Icons.search,
                        color: ColorData.maincolor,
                      ),
                      hintText: "Search",
                      hintstyle: TextStyle(
                          color: ColorData.textfieldunfocuscolor, fontSize: 15),
                    )),
              ),
            ],
          ),
          SizedBox(
            height: MyApp.height * .02,
          ),
          Expanded(
              child: ListView.builder(
            shrinkWrap: true,
            itemCount: 10,
            physics: BouncingScrollPhysics(),
            itemBuilder: (context, index) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Material(
                  elevation: 5,
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Icon(
                              Icons.copy,
                              size: 12,
                              color: ColorData.textfieldunfocuscolor,
                            ),
                            SizedBox(width: 5),
                            Text(
                              "VS 2351",
                              style: TextStyle(
                                fontSize: 12,
                                color: ColorData.textfieldunfocuscolor,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 15),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            // Circle Icon
                            CircleAvatar(
                              backgroundColor: ColorData.textfieldfocuscolor,
                              child: Icon(Icons.content_paste_search_sharp,color: ColorData.whitecolor,),
                            ),
                            const SizedBox(width: 15),
                            // Text Details
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  RichText(
                                    text: TextSpan(
                                      text: "Roofing type: ",
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: ColorData.maincolor,
                                        fontWeight: FontWeight.bold,
                                      ),
                                      children: [
                                        TextSpan(
                                          text: "Car Porch",
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: ColorData.maincolor,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  RichText(
                                    text: TextSpan(
                                      text: "Customer Name: ",
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: ColorData.textfieldunfocuscolor,
                                        fontWeight: FontWeight.w400,
                                      ),
                                      children: [
                                        TextSpan(
                                          text: "Amal",
                                          style: TextStyle(
                                            color:
                                                ColorData.textfieldunfocuscolor,
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.location_on,
                                        color: ColorData.maincolor,
                                        size: 18,
                                      ),
                                      const SizedBox(width: 5),
                                      Text(
                                        "Kochi",
                                        style: TextStyle(
                                          fontSize: 12,
                                          color: ColorData.maincolor,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            // "See Details" Button
                            CommonMaterialButton(
                              padding: EdgeInsets.symmetric(horizontal: 5),
                              elevation: 5,
                              color: ColorData.maincolor,
                              onPressed: () {},
                              child: TextThemedel(
                                text: "See details",
                                fontWeight: FontWeight.bold,
                                color: ColorData.whitecolor,
                              ),
                            )
                          ],
                        ),
                        const SizedBox(height: 15),
                        // Bottom Row with Location Icon and Address
                      ],
                    ),
                  ),
                )),
          ))
        ],
      ),
    );
  }
}
