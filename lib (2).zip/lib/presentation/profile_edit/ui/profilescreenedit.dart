import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iroofing/common/bottomsheet/BottomSheet.dart';
import '../../../common/Color/Colordata.dart';
import '../../../main.dart';

class ProfilescreenEdit extends StatelessWidget {
  const ProfilescreenEdit({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorData.bgcolor,
      appBar: AppBar(
        backgroundColor: ColorData.maincolor,
        title: Image.asset(
          "assets/logo.png",
          height: MyApp.height * .05,
        ),
        actions: [
          IconButton(
              onPressed: () {},
              icon: Icon(
                CupertinoIcons.bell_fill,
                color: ColorData.whitecolor,
              ))
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Container(
          decoration: BoxDecoration(
            color: ColorData.whitecolor,
            borderRadius: BorderRadius.circular(10)
          ),
          child: Column(
            children: [
              Row(
                children: [
                  IconButton(onPressed: () {
                    Get.off(()=>Bottomsheet());
                  }, icon: Icon(Icons.arrow_back_ios)),
                ],
              ),
              const Center(
                  child: CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage('assets/profileimg.png'),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}


