import 'package:get/get.dart';

class SiteVisitorController extends GetxController{}