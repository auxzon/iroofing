import 'package:get/get.dart';

class ForgotpasswordController extends GetxController{

}