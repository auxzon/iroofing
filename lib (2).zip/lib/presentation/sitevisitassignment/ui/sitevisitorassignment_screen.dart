import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iroofing/presentation/sitevisitassignment/controller/sitevisitorassignmentcontroller.dart';

class SitevisitorassignmentScreen extends StatelessWidget {
  const SitevisitorassignmentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var controller = Get.put(SitevisitorAssignmetController());
    return Container(
      color: Colors.blue,
    );
  }
}
