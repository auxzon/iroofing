import 'package:get/get.dart';

class SitevisitorAssignmetController extends GetxController
{}